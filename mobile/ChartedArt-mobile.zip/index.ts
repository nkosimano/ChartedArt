import { registerRootComponent } from 'expo';
import App from './App.js';

registerRootComponent(App);